package com.example.industrial_training_music_app;

public interface ActionPlaying {
    void btn_play_pauseClicked();
    void btn_prevClicked();
    void btn_nextClicked();
}
